{
  "Id": "foo",
  "Caption": "anthony quinn",
  "Description": null,
  "DateTaken": "2019-09-23T00:00:00",
  "Userid": "joe"
}