﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace ImageSharingWithCloudStorage.Models
{
    public class TagView
    {
        public virtual int Id {get; set; }
    }
}
