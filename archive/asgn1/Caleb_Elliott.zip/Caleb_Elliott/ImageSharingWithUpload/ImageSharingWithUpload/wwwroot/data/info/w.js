{
  "Id": "w",
  "Caption": "w",
  "Description": "w",
  "DateTaken": "2020-09-23T00:00:00",
  "Userid": "v"
}