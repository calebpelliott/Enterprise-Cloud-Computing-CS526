{
  "Id": "e",
  "Caption": "e",
  "Description": "e",
  "DateTaken": "1999-09-09T00:00:00",
  "Userid": "hr"
}