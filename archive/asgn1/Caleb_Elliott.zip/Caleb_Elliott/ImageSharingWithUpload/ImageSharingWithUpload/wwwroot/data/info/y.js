{
  "Id": "y",
  "Caption": "y",
  "Description": "y",
  "DateTaken": "2020-09-17T00:00:00",
  "Userid": "v"
}