{
  "Id": "1",
  "Caption": "anthony quinn",
  "Description": "Anthony Quinn, always great.",
  "DateTaken": "2020-09-11T00:00:00",
  "Userid": "joe"
}