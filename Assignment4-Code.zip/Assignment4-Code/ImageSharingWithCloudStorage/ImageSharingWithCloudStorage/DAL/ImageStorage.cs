﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;


namespace ImageSharingWithCloudStorage.DAL
{
    public class ImageStorage : IImageStorage
    {

        public const string ACCOUNT = "imagesharing";
        public const string CONTAINER = "images";

        protected readonly IWebHostEnvironment hostingEnvironment;

        protected ILogger<ImageStorage> logger;

        protected BlobServiceClient blobServiceClient;

        protected BlobContainerClient containerClient;

        protected bool UseBlobStorage { get; set; }

        public ImageStorage(IOptions<StorageOptions> storageOptions,
                            IWebHostEnvironment hostingEnvironment,
                            ILogger<ImageStorage> logger)
        {
            this.logger = logger;

            this.hostingEnvironment = hostingEnvironment;

            string connectionString = storageOptions.Value.ImageDb;

            UseBlobStorage = (connectionString != null && !("".Equals(connectionString)));

            if (UseBlobStorage)
            {
                logger.LogInformation("Using remote blob storage.");

                blobServiceClient = new BlobServiceClient(connectionString);

                containerClient = new BlobContainerClient(connectionString, CONTAINER);
            } 
            else
            {
                logger.LogInformation("Storing images on local file system.");
                mkDirectories();
            }
        }

        protected void mkDirectories()
        {
            var dataDir = Path.Combine(hostingEnvironment.WebRootPath,
               "data", "images");
            if (!Directory.Exists(dataDir))
            {
                Directory.CreateDirectory(dataDir);
            }
        }

        /**
         * The path on the local file system for a saved image.
         */
        protected string imageDataFile(int imageId)
        {
            return Path.Combine(
               hostingEnvironment.WebRootPath,
               "data", "images", "img-" + imageId + ".jpg");
        }

        /**
         * The context path on the local Web server for a saved image (must start with ~/).
         */
        protected static string imageContextPath(int imageId)
        {
            return "~/data/images/img-" + imageId + ".jpg";
        }

        /**
         * The name of a blob containing a saved image (id is key for metadata record).
         */
        protected static string BlobName (int imageId)
        {
            return "image-" + imageId + ".jpg";
        }

        protected string BlobUri (int imageId)
        {
            return containerClient.Uri + "/" + CONTAINER + "/" + BlobName(imageId);
        }

        public async Task SaveFileAsync(IFormFile imageFile, int imageId)
        {
            if (UseBlobStorage) {

                logger.LogInformation("Saving image {0} to blob storage", imageId);

                BlobHttpHeaders headers = new BlobHttpHeaders();
                headers.ContentType = "image/jpeg";
                
                // TODO upload data to blob storage


            } 
            else
            {
                logger.LogInformation("Saving image {0} to local storage", imageId);

                mkDirectories();
                // TODO save image to local storage

            }
        }

        public string ImageUri(IUrlHelper urlHelper, int imageId)
        {
            if (UseBlobStorage)
            {
                return BlobUri(imageId);
            }
            else
            {
                return urlHelper.Content(imageContextPath(imageId));
            }
        }

    }
}